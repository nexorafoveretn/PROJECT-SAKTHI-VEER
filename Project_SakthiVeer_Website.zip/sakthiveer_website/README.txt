PROJECT SAKTHIVEER WEBSITE
===========================

Open index.html in any modern browser.

The site is a responsive single-page presentation built from the information in:
- Project_SakthiVeer_Updated_with_Cover.pdf
- Perungudi_Dump_Yard_Transformation_Thesis.pdf
- Coimbatore_Vellalore_Dump_Yard_Transformation_Thesis.pdf
- Madurai_Avaniapuram_Dump_Yard_Transformation_Thesis_v2.pdf
- Project Sakthi Veer Expenditure Report.pdf

Important: financial and technical figures are presented as project-document / feasibility figures, not independently verified results.
